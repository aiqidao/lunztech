package cn.itcast.map.core;

import android.content.Context;
import android.widget.Toast;

public class ToastUtil {

	/**
	 * 短吐司
	 * 
	 * @param context
	 * @param message
	 */
	public static void shortToast(Context context, String message) {
		Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
	}

	/**
	 * 长吐司
	 * 
	 * @param context
	 * @param message
	 */
	public static void longToast(Context context, String message) {
		Toast.makeText(context, message, Toast.LENGTH_LONG).show();
	}
}
