package cn.itcast.map.core;

import android.app.Activity;
import android.os.Bundle;

import com.baidu.mapapi.BMapManager;
import com.baidu.mapapi.MKGeneralListener;
import com.baidu.mapapi.map.MapView;

//
/**
 * 封装地图显示过程的基类
 * 
 * @author weng
 * 
 */
public abstract class MapActivity extends Activity implements MKGeneralListener {

	// 授权码
	private static final String APP_KEY_CODE = "D976F126B7DB3D751A19444CD4C22FF41818F3E6";

	/**
	 * 地图引擎
	 */
	private BMapManager mEngine;

	/**
	 * 上下文件对象
	 */
	// private Context mContext;

	protected MapView mMapView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// mContext = getBaseContext();

		// 创建引擎对象
		mEngine = new BMapManager(this);

		// 引擎初始化
		mEngine.init(APP_KEY_CODE, this);

		onMapViewCreate();

	}

	/**
	 * 初始化地图控件的方法
	 */
	public abstract void onMapViewCreate();

	// 用户关心地图应用显示数据
	@Override
	protected void onStart() {
		super.onStart();
		mMapView.onResume();
		System.out.println("--onStart----");
	}

	// 不关心 HOME
	@Override
	protected void onStop() {
		super.onStop();
		System.out.println("--onStop----");
		mMapView.onPause();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (mEngine != null) {
			mEngine.destroy();// recycle release destroy
		}
	}

	// 如果手机的网络没打开
	@Override
	public void onGetNetworkState(int iError) {
		System.out.println("---onGetNetworkState----setting-");
	}

	// 如果授权码过期 非法
	@Override
	public void onGetPermissionState(int iError) {
		System.out.println("---onGetPermissionState-----");

	}

}
