package cn.itcast.map.core;

import android.app.Activity;
import android.os.Bundle;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;

/**
 * 封装了定位过程的Activity [ <service android:name="com.baidu.location.f"
 * android:enabled="true" android:process=":remote" >]
 * 
 * 【 <!-- gps卫星定位 精度高 --> <uses-permission
 * android:name="android.permission.ACCESS_FINE_LOCATION" /> <uses-permission
 * android:name="android.permission.ACCESS_GPS" />
 * 
 * <!-- 百度定位权限 --> <permission
 * android:name="android.permission.BAIDU_LOCATION_SERVICE" />
 * 
 * <uses-permission android:name="android.permission.BAIDU_LOCATION_SERVICE" />
 * 
 * <!-- 精度低 --> <uses-permission
 * android:name="android.permission.ACCESS_COARSE_LOCATION" />
 * 
 * <!-- 模拟 --> <uses-permission
 * android:name="android.permission.ACCESS_MOCK_LOCATION" />】
 * 
 * @author weng
 * 
 */
public abstract class LocationActivity extends Activity implements BDLocationListener {
	/**
	 * 定位查询器
	 */
	private LocationClient mLocationClient;
	/***
	 * 定位参数
	 */
	private LocationClientOption mOption;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		// 创建定位对象
		mLocationClient = new LocationClient(this);

		// 定位参数配置对象
		mOption = new LocationClientOption();
		// 打开gps
		mOption.setOpenGps(true);
		// 返回详细的定位信息
		mOption.setAddrType("all");
		// 采用百度的定位坐标
		mOption.setCoorType("bd09ll");
		// gps 相当耗电
		mOption.setScanSpan(5000);
		// 设置给定位查询器
		mLocationClient.setLocOption(mOption);
	}

	// 用户不关心本界面
	@Override
	protected void onStop() {
		super.onStop();
		// 关闭定位
		mLocationClient.stop();
		// 移除监听
		mLocationClient.unRegisterLocationListener(this);
	}

	@Override
	protected void onStart() {
		super.onStart();
		// 注册监听
		mLocationClient.registerLocationListener(this);
		// 打开定位功能
		mLocationClient.start();
		// 请求定位
		mLocationClient.requestLocation();

	}

	// 当手机经过N秒获取到定位信息触发
	@Override
	public void onReceiveLocation(BDLocation location) {
		if (location != null) {
			// 获取中文件地址
			String zhAddress = location.getAddrStr();
			double lat = location.getLatitude();
			double lon = location.getLongitude();
			String zhCity = location.getCity();
			onLocationGot(zhCity, lat, lon, zhAddress);
			// ------------获取完一次信息
			// 关闭定位
			mLocationClient.stop();
			// 移除监听
			mLocationClient.unRegisterLocationListener(this);
		}

	}

	/**
	 * 当手机经过N秒获取到定位信息触发
	 * 
	 * @param zhCity
	 * @param lat
	 * @param lon
	 * @param zhAddress
	 */
	public abstract void onLocationGot(String zhCity, double lat, double lon, String zhAddress);

	@Override
	public void onReceivePoi(BDLocation location) {

	}

}
