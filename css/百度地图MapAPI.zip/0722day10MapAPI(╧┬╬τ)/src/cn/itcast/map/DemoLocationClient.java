package cn.itcast.map;

import cn.itcast.map.core.MapLocationActivity;
import cn.itcast.map.core.ToastUtil;

import com.baidu.mapapi.map.MapView;

//学习定位
public class DemoLocationClient extends MapLocationActivity {

	@Override
	public void onMapViewCreate() {
		setContentView(R.layout.activity_demo_map_view);
		//
		mMapView = (MapView) findViewById(R.id.mapview);
		mMapView.setTraffic(true);

	}

	@Override
	public void onLocationGot(String zhCity, double lat, double lon, String zhAddress) {

		// 11-12 14:49:10.175: I/System.out(15294): 广州市 广东省广州市天河区棠东东路自编41首层-3铺
		// 23.133747,113.396035
		System.out.println(zhCity + "  " + zhAddress + "  " + lat + "," + lon);
		ToastUtil.shortToast(this, zhCity + "  " + zhAddress + "  " + lat + "," + lon);
	}

}
