package cn.itcast.map;

import cn.itcast.map.core.MapActivity;

import com.baidu.mapapi.map.MapView;
//显示地图检测环境搭建成功
public class DemoMapView extends MapActivity {

	@Override
	public void onMapViewCreate() {
		setContentView(R.layout.activity_demo_map_view);
		//
		mMapView = (MapView) findViewById(R.id.mapview);

	}

}
